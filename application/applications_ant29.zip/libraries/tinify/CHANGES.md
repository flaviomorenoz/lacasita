## 1.5.2
* Fail early if version of curl/openssl is too old.

## 1.5.1
* Expose status of exceptions.

## 1.5.0
* Retry failed requests by default.
* Throw clearer errors when curl is installed but disabled.

## 1.4.0
* Support for HTTP proxies.
