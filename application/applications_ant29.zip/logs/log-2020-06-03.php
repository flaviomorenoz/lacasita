<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 09:05:58 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 09:05:58 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 09:05:58 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 09:07:13 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-03 09:07:13 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-03 09:07:13 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-03 09:07:51 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 09:07:51 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 09:07:51 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 09:09:16 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 09:09:16 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 09:09:16 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 10:05:24 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 10:05:24 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 10:05:24 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 10:05:32 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 10:05:32 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 10:05:32 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 10:19:25 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:19:25 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:19:26 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:19:26 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:19:59 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:19:59 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:20:18 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:20:18 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:20:45 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:20:45 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:20:46 --> Query error: Unknown column 'item_name' in 'field list' - Invalid query: select distinct item_name fromcr_order_products
ERROR - 2020-06-03 10:20:46 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 182
ERROR - 2020-06-03 10:21:15 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 10:21:15 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 10:21:15 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 10:21:39 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:39 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:39 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:21:41 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:41 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:41 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:21:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:21:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:21:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:21:50 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:21:50 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:21:50 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:22:36 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:22:36 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:22:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:23:37 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:23:37 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:23:37 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 187
ERROR - 2020-06-03 10:24:17 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:24:17 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:24:17 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:24:19 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:24:19 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:24:19 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:24:19 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:24:19 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:24:19 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:24:20 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:24:20 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:24:20 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:25:33 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:25:33 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:25:33 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:46 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:46 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:46 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:29:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:29:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:29:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:31:23 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 10:31:23 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 10:31:23 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 10:31:27 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-03 10:31:27 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-03 10:31:27 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-03 10:31:37 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-03 10:31:37 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-03 10:31:37 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-03 10:31:42 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-03 10:31:42 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-03 10:31:42 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-03 10:34:33 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:34:33 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:34:33 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:01 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:01 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:01 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:02 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:02 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:02 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:03 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:03 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:03 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:03 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:03 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:03 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:25 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:25 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:25 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:26 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:26 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:26 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:26 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:26 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:26 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:36:36 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:36:36 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:36:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:37:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:37:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:37:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:37:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:37:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:37:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:37:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:37:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:37:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:37:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:37:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:37:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:38:10 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:38:10 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:38:10 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:38:11 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:38:11 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:38:11 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:39:00 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:39:00 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:39:00 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:39:10 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:39:10 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:39:10 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:40:16 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:16 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:16 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:40:17 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:17 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:17 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:40:18 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:18 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:18 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 189
ERROR - 2020-06-03 10:40:43 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:43 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:43 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:44 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:44 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:44 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:44 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:44 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:44 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:45 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:45 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:45 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:46 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:46 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:46 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:53 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:53 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:53 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:40:54 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:40:54 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:40:54 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:45 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:45 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:45 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:45 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:45 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:45 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:42:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:42:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:42:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 11:43:38 --> Severity: error --> Exception: syntax error, unexpected '.21' (T_DNUMBER) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 190
ERROR - 2020-06-03 11:43:39 --> Severity: error --> Exception: syntax error, unexpected '.21' (T_DNUMBER) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 190
ERROR - 2020-06-03 11:43:48 --> Severity: error --> Exception: syntax error, unexpected '.21' (T_DNUMBER) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 190
ERROR - 2020-06-03 10:43:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:43:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:43:50 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:50 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:50 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:43:50 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:50 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:50 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:43:51 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:51 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:51 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:43:51 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:43:51 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:43:51 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:08 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:08 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:08 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:09 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:09 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:09 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:10 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:10 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:10 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:13 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:13 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:13 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:13 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:13 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:13 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:14 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:14 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:14 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:15 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:15 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:15 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:17 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:17 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:17 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:36 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:36 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:37 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:37 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:37 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:44:40 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:44:40 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:44:40 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:23 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:23 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:23 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:24 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:24 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:24 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:34 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:34 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:34 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:35 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:35 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:35 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:47 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:47 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:47 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:48 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:48 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:48 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:49 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:49 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:49 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:50 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:50 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:50 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:50 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:50 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:50 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:51 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:51 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:51 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:51 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:51 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:51 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:52 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:52 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:52 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:52 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:52 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:52 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:52 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:52 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:52 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:52 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:52 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:52 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:52 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:52 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:52 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:45:53 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:45:53 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:45:53 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:46:15 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:46:15 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:46:15 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:46:15 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:46:15 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:46:15 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:46:16 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:46:16 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:46:16 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:46:17 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-03 10:46:17 --> Query error:  - Invalid query: 
ERROR - 2020-06-03 10:46:17 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-03 10:47:18 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:47:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:51:33 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:51:34 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:51:35 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:51:35 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:51:37 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:04 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:05 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:05 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:07 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:08 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:08 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:09 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:10 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:10 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:11 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:12 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:16 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:52:18 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:53:47 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:53:48 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:42 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:53 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:54 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:54 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:55 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:56 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:58 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:55:59 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:17 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:17 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:18 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 10:56:20 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:18 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:19 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:23 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:24 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:24 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:35 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:36 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:41 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-03 11:02:41 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-03 11:02:41 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-03 11:02:49 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:02:51 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 179
ERROR - 2020-06-03 11:03:05 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 11:03:06 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 11:03:07 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 11:03:07 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 11:03:08 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 11:03:08 --> Severity: error --> Exception: Call to undefined method MY_Loader::db() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-03 12:09:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 12:09:08 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 12:09:09 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 12:09:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 12:09:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 12:09:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 208
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 201
ERROR - 2020-06-03 11:49:47 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/qsysrnjx/public_html/memo/application/modules/admin/views/dashboard.php 169
ERROR - 2020-06-03 11:49:50 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/qsysrnjx/public_html/memo/application/modules/admin/views/dashboard.php 169
ERROR - 2020-06-03 11:49:51 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/qsysrnjx/public_html/memo/application/modules/admin/views/dashboard.php 169
ERROR - 2020-06-03 11:49:55 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/qsysrnjx/public_html/memo/application/modules/admin/views/dashboard.php 169
ERROR - 2020-06-03 20:26:48 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 20:26:48 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 20:26:48 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 20:27:11 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 412
ERROR - 2020-06-03 20:27:11 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 134
ERROR - 2020-06-03 20:27:11 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/item_wise_reports.php 135
ERROR - 2020-06-03 20:33:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
