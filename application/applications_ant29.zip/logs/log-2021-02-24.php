<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-24 16:08:21 --> Could not find the language line "activation_email_unsuccessful"
