<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-25 13:47:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
