<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-24 19:06:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-12-24 19:06:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-12-24 19:06:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-12-24 19:06:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-12-24 19:06:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-12-24 19:10:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-12-24 19:10:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-12-24 19:11:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
