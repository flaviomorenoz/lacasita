<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-27 17:56:14 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:56:20 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:56:27 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:56:42 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:57:49 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:58:16 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 206
ERROR - 2021-02-27 17:58:32 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 207
ERROR - 2021-02-27 18:00:11 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\varios\qsystem\lacasita\system\core\Config.php 208
