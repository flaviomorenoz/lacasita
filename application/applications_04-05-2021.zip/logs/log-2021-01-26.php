<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-26 04:09:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-26 04:09:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-26 16:20:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-26 16:20:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-26 16:21:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-26 16:48:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
