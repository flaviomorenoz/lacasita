<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 18:44:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-23 18:44:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-23 18:44:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 233
ERROR - 2021-01-23 18:44:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
