<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-05 12:50:38 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-05 12:50:38 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-05 12:50:38 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-05 12:50:53 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-05 12:50:53 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-05 12:50:53 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-05 12:51:00 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-05 12:51:00 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-05 12:51:00 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-05 12:51:02 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-05 12:51:02 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-05 12:51:02 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
ERROR - 2020-06-05 14:17:04 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 165
ERROR - 2020-06-05 14:17:05 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 165
ERROR - 2020-06-05 14:17:06 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 165
ERROR - 2020-06-05 13:19:07 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:07 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:07 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Romero order by op.item_name' at line 1 - Invalid query: SELECT DISTINCT(op.item_name) FROM cr_orders o left join cr_order_products op on o.order_id = op.order_id WHERE customer_name =Flavio Romero order by op.item_name
ERROR - 2020-06-05 13:19:07 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:08 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:08 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:08 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Romero order by op.item_name' at line 1 - Invalid query: SELECT DISTINCT(op.item_name) FROM cr_orders o left join cr_order_products op on o.order_id = op.order_id WHERE customer_name =Flavio Romero order by op.item_name
ERROR - 2020-06-05 13:19:08 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:27 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:27 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:27 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:27 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:28 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:28 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:28 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:19:36 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 13:19:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0Flavio Romero' at line 1 - Invalid query: 0Flavio Romero 
ERROR - 2020-06-05 13:19:36 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:20:42 --> Query error: Unknown column 'op.item_name' in 'field list' - Invalid query: SELECT DISTINCT(op.item_name) FROM cr_orders o
ERROR - 2020-06-05 13:20:42 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:20:43 --> Query error: Unknown column 'op.item_name' in 'field list' - Invalid query: SELECT DISTINCT(op.item_name) FROM cr_orders o
ERROR - 2020-06-05 13:20:43 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:21:05 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:05 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2020-06-05 13:21:05 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:21:05 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:05 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2020-06-05 13:21:05 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:21:37 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:37 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2020-06-05 13:21:37 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 13:21:38 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:38 --> Severity: Warning --> A non-numeric value encountered /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 166
ERROR - 2020-06-05 13:21:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0' at line 1 - Invalid query: 0
ERROR - 2020-06-05 13:21:38 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/models/Base_model.php 26
ERROR - 2020-06-05 14:35:15 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 14:35:17 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 14:35:17 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 14:35:18 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 14:40:21 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 186
ERROR - 2020-06-05 14:40:36 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-05 14:40:40 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 191
ERROR - 2020-06-05 14:40:55 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 195
ERROR - 2020-06-05 14:55:51 --> Severity: error --> Exception: syntax error, unexpected 'result' (T_STRING) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 14:55:51 --> Severity: error --> Exception: syntax error, unexpected 'result' (T_STRING) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 180
ERROR - 2020-06-05 15:21:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:21:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:22:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 233
ERROR - 2020-06-05 15:23:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:23:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:24:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:25:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-06-05 15:30:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:30:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:30:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:31:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:31:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:31:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:31:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-06-05 15:31:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 233
ERROR - 2020-06-05 15:36:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 15:37:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-05 16:48:02 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 181
ERROR - 2020-06-05 16:48:03 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 181
ERROR - 2020-06-05 15:49:01 --> Severity: error --> Exception: Call to a member function input() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 172
ERROR - 2020-06-05 15:49:27 --> Severity: error --> Exception: Call to a member function input() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 172
ERROR - 2020-06-05 15:49:29 --> Severity: error --> Exception: Call to a member function input() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 172
ERROR - 2020-06-05 15:49:31 --> Severity: error --> Exception: Call to a member function input() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 172
ERROR - 2020-06-05 16:06:05 --> Severity: error --> Exception: Call to a member function row() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 170
ERROR - 2020-06-05 16:06:07 --> Severity: error --> Exception: Call to a member function row() on null /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 170
ERROR - 2020-06-05 16:11:40 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:40 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:40 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 16:11:42 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:42 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:42 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 16:11:42 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:42 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:42 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 16:11:43 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:43 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:43 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 16:11:44 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:44 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:44 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
ERROR - 2020-06-05 16:11:44 --> Severity: Warning --> mysqli::query(): Empty query /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
ERROR - 2020-06-05 16:11:44 --> Query error:  - Invalid query: 
ERROR - 2020-06-05 16:11:44 --> Severity: error --> Exception: Call to a member function result() on bool /home/qsysrnjx/public_html/memo/application/modules/admin/controllers/Admin.php 167
