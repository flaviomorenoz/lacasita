<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-25 09:13:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 09:13:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 10:19:43 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:19:47 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:19:59 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:20:49 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:21:23 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:21:37 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 10:21:44 --> Severity: error --> Exception: syntax error, unexpected '}' /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 10
ERROR - 2020-05-25 09:26:15 --> Severity: error --> Exception: syntax error, unexpected '<' /home/qsysrnjx/public_html/memo/application/modules/reports/views/client_wise_reports.php 84
ERROR - 2020-05-25 11:22:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:24:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:25:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:27:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:27:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:27:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:28:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:29:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 11:29:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 11:33:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 15:48:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 16:15:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 16:53:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 17:01:57 --> Severity: error --> Exception: syntax error, unexpected ';' /home/qsysrnjx/public_html/memo/application/modules/orders/views/view_order.php 63
ERROR - 2020-05-25 17:08:23 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 17:08:23 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 22:48:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2020-05-25 22:48:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 22:48:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:01:10 --> Could not find the language line "activation_email_unsuccessful"
ERROR - 2020-05-25 23:03:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:03:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:03:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:03:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:03:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:03:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:04:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:07:21 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:07:21 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:01 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:01 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:30 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:30 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:55 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:08:55 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:11 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:11 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:24 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:24 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:38 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:09:38 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:16:46 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:16:46 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:28:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-25 23:29:12 --> Severity: Warning --> number_format() expects parameter 2 to be int, string given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:29:12 --> Severity: Warning --> str_replace() expects at least 3 parameters, 2 given /home/qsysrnjx/public_html/memo/application/modules/orders/controllers/Orders.php 836
ERROR - 2020-05-25 23:32:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
