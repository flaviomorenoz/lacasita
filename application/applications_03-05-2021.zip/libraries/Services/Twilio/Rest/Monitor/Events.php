<?php

class Services_Twilio_Rest_Monitor_Events extends Services_Twilio_MonitorListResource {

}
