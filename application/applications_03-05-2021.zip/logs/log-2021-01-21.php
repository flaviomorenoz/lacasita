<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 12:03:28 --> Could not find the language line "activation_email_unsuccessful"
ERROR - 2021-01-21 12:07:06 --> Could not find the language line "activation_email_unsuccessful"
