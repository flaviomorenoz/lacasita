<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-20 09:23:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 09:23:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-05-20 09:23:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 09:25:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 09:25:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 09:25:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 17:22:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 17:22:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 17:22:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 17:22:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-20 17:22:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
