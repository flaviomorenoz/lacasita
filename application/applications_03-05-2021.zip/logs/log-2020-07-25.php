<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-25 00:02:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-25 00:02:21 --> Unable to connect to the database
ERROR - 2020-07-25 00:02:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-25 00:02:21 --> Unable to connect to the database
ERROR - 2020-07-25 00:02:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-25 00:02:21 --> Unable to connect to the database
ERROR - 2020-07-25 00:02:21 --> Severity: error --> Exception: Call to a member function query() on bool /home/qsysrnjx/public_html/memo/system/database/drivers/mysqli/mysqli_driver.php 221
