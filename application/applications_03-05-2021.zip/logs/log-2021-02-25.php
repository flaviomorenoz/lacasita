<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-25 08:43:44 --> Could not find the language line "activation_email_unsuccessful"
ERROR - 2021-02-25 15:08:41 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 15:08:48 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 15:34:14 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:19:12 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:19:18 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:20:00 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:20:01 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:28:06 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:32:57 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:32:59 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:32:59 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:34:06 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:34:08 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:42:28 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:44:11 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:44:40 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:44:41 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:44:43 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:44:44 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:35 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:35 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:36 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:36 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:36 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:37 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:37 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:37 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:37 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:37 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:45:38 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:46:29 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:46:30 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:47:44 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:47:45 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:47:46 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:47:46 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:48:32 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:48:33 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:49:14 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:49:15 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:50:05 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:50:06 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:50:06 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 16:55:57 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:47 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:48 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:49 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:49 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:49 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:49 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:54 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:08:59 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:11:15 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:13:31 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\controllers\Welcome.php 16
ERROR - 2021-02-25 17:14:26 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:14:28 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:14:59 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:15:00 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:15:00 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:15:00 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:15:01 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:15:14 --> Severity: error --> Exception: Call to a member function logged_in() on null D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\controllers\Welcome.php 9
ERROR - 2021-02-25 17:15:15 --> Severity: error --> Exception: Call to a member function logged_in() on null D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\controllers\Welcome.php 9
ERROR - 2021-02-25 17:15:15 --> Severity: error --> Exception: Call to a member function logged_in() on null D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\controllers\Welcome.php 9
ERROR - 2021-02-25 17:15:16 --> Severity: error --> Exception: Call to a member function logged_in() on null D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\controllers\Welcome.php 9
ERROR - 2021-02-25 17:16:31 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:16:32 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:19:55 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:19:55 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:22:10 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 17:22:39 --> Severity: error --> Exception: syntax error, unexpected 'elseif' (T_ELSEIF) D:\xampp\htdocs\varios\qsystem\lacasita\application\models\Ion_auth_model.php 977
ERROR - 2021-02-25 11:37:27 --> Could not find the language line "activation_email_unsuccessful"
ERROR - 2021-02-25 11:38:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 11:54:55 --> Could not find the language line "activation_email_unsuccessful"
ERROR - 2021-02-25 18:01:15 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\auth\controllers\Auth.php 206
ERROR - 2021-02-25 18:04:35 --> Severity: error --> Exception: syntax error, unexpected 'Despues' (T_STRING), expecting ',' or ';' D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\auth\controllers\Auth.php 207
ERROR - 2021-02-25 18:32:13 --> Severity: Compile Error --> Can't use method return value in write context D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\auth\controllers\Auth.php 212
ERROR - 2021-02-25 12:52:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 12:52:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 15:43:24 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\reports\controllers\Reports.php 159
ERROR - 2021-02-25 15:43:24 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\reports\views\date_wise_reports.php 78
ERROR - 2021-02-25 15:43:24 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\reports\views\date_wise_reports.php 79
ERROR - 2021-02-25 16:40:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 16:43:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 16:45:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-02-25 20:28:48 --> Severity: error --> Exception: Call to undefined method Ion_auth_model::register() D:\xampp\htdocs\varios\qsystem\lacasita\application\libraries\Ion_auth.php 341
ERROR - 2021-02-25 20:34:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
