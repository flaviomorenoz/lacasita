<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 21:24:51 --> Could not find the language line "activation_email_unsuccessful"
