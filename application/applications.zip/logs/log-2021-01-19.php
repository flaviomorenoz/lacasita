<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-19 21:18:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 277
ERROR - 2021-01-19 21:19:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 277
