<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 17:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-17 17:39:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
