<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-16 19:58:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-16 19:58:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-16 19:59:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-16 19:59:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-16 22:24:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2021-01-16 22:25:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/lacanycu/public_html/application/modules/welcome/models/Welcome_model.php 88
