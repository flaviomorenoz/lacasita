<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-17 18:19:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:19:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:20:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:20:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:20:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-05-17 18:20:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 179
ERROR - 2020-05-17 18:20:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 233
ERROR - 2020-05-17 18:20:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 233
