<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-07 23:42:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/qsysrnjx/public_html/memo/application/modules/welcome/models/Welcome_model.php 88
ERROR - 2020-06-07 23:59:34 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/controllers/Reports.php 159
ERROR - 2020-06-07 23:59:34 --> Severity: Warning --> Use of undefined constant Todos - assumed 'Todos' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 78
ERROR - 2020-06-07 23:59:34 --> Severity: Warning --> Use of undefined constant Nuevo - assumed 'Nuevo' (this will throw an Error in a future version of PHP) /home/qsysrnjx/public_html/memo/application/modules/reports/views/date_wise_reports.php 79
