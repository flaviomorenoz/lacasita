<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-02 09:48:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\welcome\models\Welcome_model.php 88
ERROR - 2021-03-02 16:11:59 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ')' D:\xampp\htdocs\varios\qsystem\lacasita\application\modules\orders\controllers\Orders.php 49
