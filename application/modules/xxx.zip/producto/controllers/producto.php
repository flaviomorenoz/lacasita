<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//error_reporting(E_ALL & ~E_NOTICE & ~E_PARSE & ~E_WARNING & ~E_ERROR);
//ini_set('display_errors', '1');

/*
class Producto extends MY_Controller{

    function __construct(){
        //die("Dua Lipa");
        parent::__construct();
        $this->load->model('producto_model');
    }

    function agregar(){
        $this->data['content']         	= "producto/agregar";
        $this->_render_page('C://xampp/htdocs/varios/qsystem/lacasita/application/views/templates/inv-template', $this->data);
        //$this->_render_page('C:\\xampp\htdocs\varios\qsystem\lacasita\application\views\templates\inv-template', $this->data);
        //$this->load->view("producto/agregar");
    }

}
*/
?>