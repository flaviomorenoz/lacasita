<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class producto_model extends CI_Model{

    public function __construct(){
        parent::__construct();
        $this->load->database(); 
    }

    function agregar(){

    	$hasError = false;
    	$ar["error"] = ""; $ar["message"] = "";

    	if(!(isset($_POST["idAlm"]) && strlen($_POST["idAlm"])>0)){
    		$hasError = true;
    		$ar["message"] = "Hubo un problema en Almacen";
    	}

    	if(!$hasError){
	    	$data["idAlm"] 			= $_POST["idAlm"];
	    	$data["descPro"] 		= $_POST["descPro"];
	    	$data["stockInicial"] 	= $_POST["stockInicial"];
	    	$data["costo"] 			= $_POST["costo"];
	    	$data["fecha"] 			= $_POST["fecha"];
	    	
	    	$this->db->insert("cr_inv_productos",$data);

	    	return $ar;
	    }else{
    		$ar["error"] = $hasError;
    		return $ar;
    	}
    }
}
?>