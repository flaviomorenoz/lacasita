<?php

?>
<div id="page-wrapper">
            
	<!-- DATOS DE CABECERA : ALMACEN -->
    <div style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
        <div class="row">
	        <div class="col-sm-2">
	        	Almacen:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="idAlm" name="idAlm" size="10">
	        </div>
	    </div>
    </div>


    <div style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
        <div class="row">
	        <div class="col-sm-2">
	        	Nombre Producto:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="descPro" name="descPro" size="30">
	        </div>
	    </div>

	    <div class="row">
	        <div class="col-sm-2">
	        	Stock Inicial:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="stockInicial" name="stockInicial" size="30">
	        </div>
	    </div>

	    <div class="row">
	        <div class="col-sm-2">
	        	Costo:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="costo" name="costo" size="30">
	        </div>
	    </div>

	    <div class="row">
	        <div class="col-sm-2">
	        	Fecha:
	        </div>

	        <div class="col-sm-3">
	        	<input type="date" id="fecha" name="fecha" size="30">
	        </div>
	    </div>

	    <div class="row">
	        <div class="col-sm-2">
   				<div class="col-sm-2" style="margin:20px;">
					<button class="btn btn-success" onclick="grabar_producto()">Grabar</button>
				</div>
			</div>
		</div>

        <div class="row">
	        <div id="pizarra1" class="col-sm-2">
	        	Pizarra1
	        </div>
	    </div>

	</div>

<script>
	function limpiar_cab(){
		//document.getElementById('ruc').value = "";
	}
	function grabar_producto(){

		var parametros = {
			idAlm 		: document.getElementById('idAlm').value,
			descPro 	: document.getElementById('descPro').value,
			stockInicial: document.getElementById('stockInicial').value,
			costo 		: document.getElementById('costo').value,
			fecha 		: document.getElementById('fecha').value

		}
		console.log("inicia grabar producto")
		$.ajax({
			data 	:parametros,
			url 	:'inventario/agregar_producto',
			type 	:'post',
			success :function(response){
				document.getElementById('pizarra1').innerHTML = response
				console.log("termina grabar producto")
			}
		})

	}
</script>

    <div class="row" style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
    	<div class="col-sm-12" id="pizarra1">
    	</div>
    </div>

</div>