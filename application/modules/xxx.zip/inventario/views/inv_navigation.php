<!-- /. NAV SIDE  -->
<style>
.dropbtn {
  background-color: transparent;
  color: white;
  padding: 8px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: transparent;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 6px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>
<section class="navbar-side" style="background-color: rgb(250,150,0); height:800px; border-style: solid; border-width: 4px; border-color:rgb(50,50,50); border-radius: 10px;">
   <ul class="nav crunchy-navigation sidebar-menu">
   
      <!--DASHBOARD-->
      <li><a class="fuerte" href="<?= base_url("inventario/agregar"); ?>" title="Ver Movimientos">
         <i class="fa fa-dashboard fa-2x"></i>
         Movimientos
         </a>
      </li>

      <li><a class="fuerte" href="<?= base_url("inventario/index"); ?>">
         <i class="fa fa-dashboard fa-2x"></i>
         Stock Actual
         </a>
      </li>

      <li>
         <div class="dropdown" style="margin-left: 20px">
            <i class="fa fa-dashboard fa-2x"></i>
           <button onclick="myFunction()" class="dropbtn" style="color:rgb(60,60,60);font-weight: bold;">Reportes</button>
           <div id="myDropdown" class="dropdown-content">
             <a href="<?= base_url("inventario/rep_entradas"); ?>">Reporte de Entradas</a>
           </div>
         </div>
      </li>
      
      <li><a class="fuerte" href="<?= base_url("inventario/agregar_producto"); ?>" title="Ver Productos">
         <i class="fa fa-dashboard fa-2x"></i>
         Productos
         </a>
      </li>
      
      <li><a class="fuerte" href="<?= base_url("receta/agregar"); ?>" title="Ver Recetas">
           <i class="fa fa-dashboard fa-2x"></i>
           Recetas
         </a>
      </li>

   </ul>
</section>
<script src="<?php echo JS_ADMIN_SIDEBAR_MENU;?>"></script>
<script>
   $.sidebarMenu($('.sidebar-menu'))

   /* When the user clicks on the button, 
   toggle between hiding and showing the dropdown content */
   function myFunction() {
     document.getElementById("myDropdown").classList.toggle("show");
   }

   // Close the dropdown if the user clicks outside of it
   window.onclick = function(event) {
     if (!event.target.matches('.dropbtn')) {
       var dropdowns = document.getElementsByClassName("dropdown-content");
       var i;
       for (i = 0; i < dropdowns.length; i++) {
         var openDropdown = dropdowns[i];
         if (openDropdown.classList.contains('show')) {
           openDropdown.classList.remove('show');
         }
       }
     }
   }
</script>