<?php
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
//require_once('C:\xampp\htdocs\varios\qsystem\lacasita\application\config\funciones.php');
//require_once("c:/xampp/htdocs" . DS . FOLDERNAME . "application/config/funciones.php");

?>
<style type="text/css">
	.tandem{
		margin-left:10px;
		font-size:8px;
	}
</style>

<div id="page-wrapper">
            
    <div class="row">
        <div class="col-md-12">
		</div><!-- fin de col -->
	
	</div><!-- fin de row -->

	<div class="row">
		<div class="col-xl-12 col-sm-12">

			<?php
			
				echo "<h2>Stock Actual</h2>";
				$result = $this->inventario_model->carga_inventario();
				//var_dump($result);
				
				echo "<table class=\"table-condensed\" style=\"border-style:solid; border-color:gray; border-width:1px;\"><thead>";
				echo "<th>" . "ID___"; 
				echo "<th>" . "PRODUCTO___"; 
				echo "<th>" . "Stock Inicial__"; 
				echo "<th>" . "Movimiento__"; 
				echo "<th>" . "Stock Actual__" . "</thead><tbody>";
				
				foreach($result as $r){
					
					echo "<tr>";
					echo "<td>" . $r["idPro"] . "</td>";
					echo "<td>" . $r["descPro"] . "</td>";
					echo "<td>" . $r["stockInicial"] . "</td>";
					echo "<td>" . $r["cantidad"] . "</td>";
					echo "<td>" . $r["total_Stock"] . "</td>";
					echo "</tr>";
				}
				echo "</tbody></table>";
			?>
			
		</div>
		
	</div>

</div>