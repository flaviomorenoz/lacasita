<style>
* {
  box-sizing: border-box;
}

/*the container must be positioned relative:*/
.autocomplete {
  /*position: relative;
  display: inline-block;*/
}

input {
  /*border: 1px solid transparent;
  background-color: #f1f1f1;
  padding: 10px;
  font-size: 16px;*/
}

input[type=text] {
  background-color: #f1f1f1;
  width: 100%;
}

input[type=submit] {
  background-color: DodgerBlue;
  color: #fff;
  cursor: pointer;
}

.autocomplete-items {
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  top: 100%;
  left: 0;
  right: 0;
}

.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #fff; 
  border-bottom: 1px solid #d4d4d4; 
}

/*when hovering an item:*/
.autocomplete-items div:hover {
  background-color: #e9e9e9; 
}

/*when navigating through the items using the arrow keys:*/
.autocomplete-active {
  background-color: DodgerBlue !important; 
  color: #ffffff; 
}
</style>

<script type="text/javascript">
	function grabar_inventario(){
		console.log("Ingresando a grabar_inventario")
		var parametros = {
			"idAlm" 		:document.getElementById('almacen').value,
			"accionMov"		:document.getElementById('accion').value,
			
			"tipodoc" 		:document.getElementById('tipodoc').value,
			"nroDoc" 		:document.getElementById('nroDoc').value,
			"idPro" 		:document.getElementById('productos').value,
			"cantidadMov" 	:document.getElementById('cantidad').value,
			"ruc" 			:document.getElementById('ruc').value,
			"razon"			:document.getElementById('razon').value,
			"fec_emi_doc" 	:document.getElementById('fec_emi_doc').value,
			"fec_venc_doc" 	:document.getElementById('fec_venc_doc').value,
			"motivo" 		:document.getElementById('motivo').value,
			"cargo_servicio":document.getElementById('cargo_servicio').value,
			"costo" 		: document.getElementById('costo').value
		}
		
		$.ajax({
			data 	:parametros,
			url 	:'inventario/agregar',
			type 	:'post',
			success :function(response){
				ar = JSON.parse(response)
				//console.log(ar["error"])
				//console.log(ar["message"])
				if(ar["error"]){
					// nothing
				}else{
					document.getElementById('accion').value = "";
					document.getElementById('productos').value = "";
					document.getElementById('cantidad').value = 0;
					document.getElementById('costo').value = 0;

					
					$.ajax({
						data: {visualizacion:'2'},
						url: 	'inventario/entradas',
						type: 	'post',
						success:function(res){
							document.getElementById('pizarra2').innerHTML = res
						}
					})
				}
				document.getElementById('pizarra1').innerHTML = ar["message"];
			}
		})


	}
</script>
<style type="text/css">
	.tandem{
		margin-left:10px;
		font-size:8px;
	}
	body{
		font-family:arial;
		color:rgb(20,20,90);
	}
	.gola{
		margin:20px;
	}
</style>

<div id="page-wrapper">
            
    <!--<h2 style="text-align:center;">Ingreso de Inventario:</h2>-->

    <div style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
        <div class="row espaciado">
	        <div class="col-sm-2">
	        	Almacen
	        </div>

	        <div class="col-sm-3">
	        	<?= $this->inventario_model->combo_almacen() ?>
	        </div>

	        <div class="col-sm-2">
	        	Tipo Doc:
	        </div>

	        <div class="col-sm-3">
	        	<?= $this->inventario_model->combo_TipoDoc() ?>
	        </div>

	    </div>

        <div class="row espaciado">

	        <div class="col-sm-2">
	        	Razon Social:
	        </div>

	        <div class="col-sm-3">
	        	<!--<form autocomplete="off" action="/action_page.php">-->
				  <div class="autocomplete" style="width:240px;">
				    <input id="razon" type="text" name="razon" placeholder="Razon Social" onblur="obtener_ruc(this)">
				  </div>
				  <!--<input type="submit">
				</form>-->
	        </div>

	        <div class="col-sm-2">
	        	Ruc:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" name="ruc" id="ruc">
	        </div>

	    </div>

        <div class="row espaciado">
	        <div class="col-sm-2">
	        	Nro. Factura/Boleta:
	        </div>

	        <div class="col-sm-3">
	        	<input name="nroDoc" id="nroDoc" placeholder="000000">
	        </div>

	        <div class="col-sm-2">
	        	
	        </div>

	        <div class="col-sm-3">
	        	
	        </div>

	    </div>

        <div class="row espaciado">
	        <div class="col-sm-2">
	        	Fec_emi:
	        </div>

	        <div class="col-sm-3">
	        	<input type="date" id="fec_emi_doc" name="fec_emi_doc" size="10">
	        </div>

	        <div class="col-sm-2">
	        	Fec_venc:
	        </div>

	        <div class="col-sm-3">
	        	<input type="date" id="fec_venc_doc" name="fec_venc_doc" size="10">
	        </div>

	    </div>	    

        <div class="row espaciado">
	        <div class="col-sm-2">
	        	Motivo:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="motivo" name="motivo" value="provision" placeholder="provision">
	        </div>

	        <div class="col-sm-2">
	        	Cargo x Servicio:
	        </div>

	        <div class="col-sm-3">
	        	<input type="text" id="cargo_servicio" name="cargo_servicio" size="10" placeholder="S/">
	        </div>

	    </div>

        <div class="row espaciado">
	        <div class="col-sm-2">

	        </div>

	        <div class="col-sm-3">
	        	
	        </div>

	        <div class="col-sm-2">
	        	
	        </div>

	        <div class="col-sm-3">
	        	<button class="btn btn-danger btn-sm" onclick="limpiar_cab()">Limpiar</button>	
	        </div>

		</div>	    	    
    </div>
<script>
	function limpiar_cab(){
		document.getElementById('ruc').value = "";
		document.getElementById('razon').value = "";
		document.getElementById('nroDoc').value = "";
		document.getElementById('ruc').value = "";
		document.getElementById('fec_emi_doc').value = "";
		document.getElementById('fec_venc_doc').value = "";
		document.getElementById('motivo').value = "provision";
		document.getElementById('cargo_servicio').value = "";
		document.getElementById('costo').value = "0";
	}

	function obtener_ruc(obj){
		console.log("en obtener_ruc:" + obj.value)
		var parametros = {
			razon:obj.value
		}
		$.ajax({
			data 	: parametros,
			url 	: 'inventario/obtener_ruc',
			type	: 'post',
			success : function(response){
				document.getElementById("ruc").value = response
			}
		})
		
	}
</script>

<!--
        	<div class="gola">Almacen:<?= $this->inventario_model->combo_almacen() ?>&nbsp;&nbsp;&nbsp;

        	Tipo Doc:<?= $this->inventario_model->combo_TipoDoc() ?></div>

        	<div class="gola">
        		<p>Ruc: 				<input type="text" name="ruc" id="ruc">
        		Razon Social: 		<input type="text" id="razon" name="razon"></p>
        		<p>Nro. Factura/Boleta:<input name="nroDoc" id="nroDoc"></p>
        		<p>Fec_emi: 			<input type="text" id="fec_emi_doc" name="fec_emi_doc" size="10">&nbsp;&nbsp;&nbsp;
        		Fec_venc: 			<input type="text" id="fec_venc_doc" name="fec_venc_doc" size="10"></p>
        		<p>Motivo: 			<input type="text" id="motivo" name="motivo"></p>
        		<p>Cargo Servicio S/:<input type="text" id="cargo_servicio" name="cargo_servicio" size="8"></p>
        	</div>
-->
    <div class="row" style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
        <div class="col-sm-12 col-12">

        	<div class="row">
	        	<div class="col-sm-2" style="margin:20px;">Accion:<?= $this->inventario_model->combo_accion() ?></div>

	        	<div class="col-sm-3" style="margin:20px;">Producto:<?= $this->inventario_model->combo_producto() ?></div>

	        	<div class="col-sm-2" style="margin:20px;">Cantidad:<input type="text" name="cantidad" id="cantidad" size="5" placeholder="Kilos"></div>
	        
				<div class="col-sm-2" style="margin:20px;">
		        	Costo sin IGV:<input type="text" name="costo" id="costo" size="8" value="0">
		        </div>

				<div class="col-sm-1" style="margin:20px;">
					<button class="btn btn-success" onclick="grabar_inventario()">Grabar</button>
				</div>
			</div>

        </div>

        <div class="col-sm-6 col-12">


        </div>
    </div>

    <div class="row" style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
    	<div class="col-sm-12" id="pizarra1">
    	</div>
    </div>

    <!-- SE VISUALIZA DETALLE DE ULTIMOS MOVIMIENTOS -->
    <div id="pizarra2" class="row" style="border-style:solid; border-color:gray; border-width: 1px; margin:20px; padding:10px;">
    	<?php 
    	$arr["visualizacion"] = 2;
    	$this->load->view("inventario/entradas",$arr); 
    	?>
    </div>

</div>
<script type="text/javascript">
function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;

      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
          b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document, except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
  });
}

/*An array containing all the country names in the world:*/
var countries = [<?= $this->inventario_model->razon(); ?>];

/*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
autocomplete(document.getElementById("razon"), countries);
</script>
