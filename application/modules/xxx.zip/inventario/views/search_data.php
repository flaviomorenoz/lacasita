<?php
$j = array();
$j[] = "flavio";
$j[] = "julio";
$j[] = "sandra";
echo json_encode($j)
?>