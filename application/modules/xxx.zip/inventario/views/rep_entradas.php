<style type="text/css">
	.tandem{
		margin-left:10px;
		font-size:8px;
	}
</style>

<script>
	function reporte(){
		var parametros = {
			desde:document.getElementById('desde').value,
			hasta:document.getElementById('hasta').value
		}
		$.ajax({
			data:parametros,
			url:'inventario/rep_entradas',
			type:'post',
			success:function(response){
				//console.log("Dale U")
				document.getElementById("pizarra1").innerHTML = response
			}
		})
	}
</script>
<div id="page-wrapper">
            
    <div class="row" style="margin-top:15px">
        <div class="col-xs-6 col-sm-3">
			desde:<input type="date" name="desde" id="desde">
		</div>

		<div class="col-xs-6 col-sm-3">
			hasta:<input type="date" name="hasta" id="hasta">
		</div>

		<div class="col-xs-6 col-sm-3">
			<button onclick="reporte()">Aceptar</button>
		</div>

	</div><!-- fin de row -->

	<div class="row">
		<div id="pizarra1" class="col-xs-12 col-sm-12">

		</div>
	</div>
</div>