<?php
	//echo("La razon llega:".$razon);
	echo $this->inventario_model->obtener_razon($razon);
?>