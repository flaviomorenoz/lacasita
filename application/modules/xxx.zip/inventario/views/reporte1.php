<h3><?= $titulo ?></h3>

<?php
				//idMov, concat(a.fechaMov, ' ',a.horaMov) fechas, a.idPro, b.descPro, a.cantidadMov, concat(a.ruc,'-',a.razon) cruc
				//
				$cEstilo = "text-align:right;";
				
				echo "<table class=\"table-condensed\"><thead>";
				echo $this->fm->celda_h("Id"); 
				echo $this->fm->celda_h("Accion");
				echo $this->fm->celda_h("Tipo Doc");
				echo $this->fm->celda_h("Ruc-Razon");
				echo $this->fm->celda_h("Emision");
				echo $this->fm->celda_h("Fechas"); 
				echo $this->fm->celda_h("Producto"); 
				echo $this->fm->celda_h("Cantidad",2,$cEstilo);
				echo $this->fm->celda_h("total",2,$cEstilo);
				echo "</thead>";
				echo "<tbody>";
				
				
				$total = 0;
				foreach($result as $r){
					echo "<tr>";
					echo $this->fm->celda($r["idMov"]);
					echo $this->fm->celda($r['accionMov']);
					echo $this->fm->celda($r["tipoDoc"]);
					echo $this->fm->celda($r["cruc"]);
					echo $this->fm->celda($r["fec_emi_doc"]);
					echo $this->fm->celda($this->fm->ymd_dmy($r["fechas"]));
					echo $this->fm->celda($r["descPro"]);
					echo $this->fm->celda($r["cantidadMov"],2);
					echo $this->fm->celda($r["costo"],2);
					$total += $r["costo"];
					echo "</tr>";
				}
				echo "</tbody>";

				echo "<tfoot>";
				echo $this->fm->celda_h(""); 
				echo $this->fm->celda_h("");
				echo $this->fm->celda_h("");
				echo $this->fm->celda_h("");
				echo $this->fm->celda_h("");
				echo $this->fm->celda_h(""); 
				echo $this->fm->celda_h(""); 
				echo $this->fm->celda_h("Total:",2,$cEstilo);
				echo $this->fm->celda_h($total,2,$cEstilo);
				//echo "<th style=\"text-align:right;\">" . "315.6" . "</th>";

				echo "</tfoot>";
				echo "</table>";
?>