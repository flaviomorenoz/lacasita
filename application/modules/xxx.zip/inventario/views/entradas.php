<?php
$result = $this->inventario_model->carga_inventario_entradas();
?>
<style type="text/css">
	.tandem{
		margin-left:10px;
		font-size:8px;
	}
</style>

<div id="page-wrapper">
            
	<div class="row">
		<div id="pizarra1" class="col-xs-12 col-sm-12">
			<h3>Registro en Almac&eacute;n</h3>
		</div>
	</div>
	
	<div class="row">
		<div id="pizarra1" class="col-xs-12 col-sm-12">

<?php
				//idMov, concat(a.fechaMov, ' ',a.horaMov) fechas, a.idPro, b.descPro, a.cantidadMov, concat(a.ruc,'-',a.razon) cruc
				//
				echo "<table class=\"table-condensed\"><thead>";
				echo $this->fm->celda_h("Id"); 
				echo $this->fm->celda_h("Fechas"); 
				echo $this->fm->celda_h("Producto"); 
				echo $this->fm->celda_h("Cantidad");
				echo $this->fm->celda_h("Tipo Doc");
				echo $this->fm->celda_h("Ruc-Razon");
				echo $this->fm->celda_h("Emision");
				echo $this->fm->celda_h("Accion");
				echo "</thead>";
				echo "<tbody>";
				
				foreach($result as $r){
					echo "<tr>";
					echo $this->fm->celda($r["idMov"]);
					echo $this->fm->celda($r["fechas"]);
					echo $this->fm->celda($r["descPro"]);
					echo $this->fm->celda($r["cantidadMov"]);
					echo $this->fm->celda($r["tipoDoc"]);
					echo $this->fm->celda($r["cruc"]);
					echo $this->fm->celda($r["fec_emi_doc"]);
					echo $this->fm->celda($r['accionMov']);
					echo "</tr>";
				}
				echo "</tbody></table>";
?>
		</div>
	</div>
</div>