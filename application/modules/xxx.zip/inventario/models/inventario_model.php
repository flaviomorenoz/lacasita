<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class inventario_model extends CI_Model{

    public function __construct(){
        parent::__construct();
        $this->load->database(); 
    }

    function carga_inventario(){
    	$cSql = "select a.idPro, a.descPro, a.stockInicial, b.cantidad, a.stockInicial + b.cantidad as total_Stock
			from cr_inv_productos a
			left join (
					select idPro, sum(if(accionMov = 'E',cantidadMov,(-1)*cantidadMov)) cantidad 
					from cr_inv_movimientos
					where idAlm = 1
					group by idPro
			) b on a.idPro = b.idPro";
		
		$result = $this->db->query($cSql)->result_array();
		return $result;
	}

    
    function carga_inventario_entradas(){
    	// a.idPro, a.descPro, a.stockInicial, b.cantidad, a.stockInicial + b.cantidad as total_Stock,
    	$cSql = "select 
			a.idMov, concat(a.fechaMov, ' ',a.horaMov) fechas, a.idPro, b.descPro, a.cantidadMov, concat(a.ruc,'-',a.razon) cruc, a.accionMov, a.tipoDoc, a.fec_emi_doc
			from cr_inv_movimientos a
			left join cr_inv_productos b on a.idPro = b.idPro
			order by a.idMov desc limit 50";

		//die($cSql);
		$result = $this->db->query($cSql)->result_array();
		return $result;
	}

	function combo_almacen(){
		$cSql = "select * from cr_inv_almacenes order by idAlm";
		$result = $this->db->query($cSql)->result();
		$cad = "<select id=\"almacen\" name=\"almacen\">";
		foreach($result as $r){
			$cad .= $this->fm->option($r->idAlm,$r->nombreAlm);
		}
		$cad .= "</select>";
		return $cad;
	}

	function combo_accion(){
		$cad = "<select id=\"accion\" name=\"accion\">";
		$cad .= $this->fm->option("E","Entrada");
		$cad .= $this->fm->option("S","Salida");
		$cad .= "</select>";
		return $cad;
	}

	function combo_producto(){
		$cSql = "select * from cr_inv_productos order by descPro";
		$result = $this->db->query($cSql)->result();
		$cad = "<select id=\"productos\" name=\"productos\">";
		foreach($result as $r){
			$cad .= $this->fm->option($r->idPro,$r->descPro);
		}
		$cad .= "</select>";
		return $cad;
	}

	function grabar($data){
		if($data["fec_emi_doc"] == ''){
			$data["fec_emi_doc"] = null;
		}

		if($data["fec_venc_doc"] == ''){
			$data["fec_venc_doc"] = null;
		}

		//var_dump($data);
		//die();
		$this->db->insert("cr_inv_movimientos",$data);
		return $this->fm->message("Grabacion Correcta",0);
	}

	function combo_TipoDoc($defecto=""){
		$cad = "<select id=\"tipodoc\" name=\"tipodoc\">";
		$cad .= $this->fm->option('F','Factura');
		$cad .= $this->fm->option('B','Boleta');
		$cad .= $this->fm->option('G','Guia Interna');
		$cad .= "</select>";
		
		return $cad;
	}

    function razon(){
        $cSql = "select * from inv_proveedores order by idProv desc limit 50";
        $result = $this->db->query($cSql)->result();
        $cad = "";
        foreach($result as $r){
            $cad .= "'" . $r->razon . "',";
            //$cad .= "'" . 'paraiso' . "',";
        }
        return substr($cad,0,strlen($cad)-1);
    }

    function obtener_razon($desc = ""){
        $cSql = "select ruc from inv_proveedores where razon = '$desc'";
        $result = $this->db->query($cSql)->result();
        $cad = "";
        foreach($result as $r){
            $cad .= $r->ruc;
		}
		return $cad;	    	
	}

	function reporte($ar_datos){
		
		if($ar_datos["opcion"] == "1"){  // Entradas desde hasta
			$desde = $ar_datos["desde"];
			$hasta = $ar_datos["hasta"];
	    	$cSql = "select 
				a.idMov, concat(a.fechaMov, ' ',a.horaMov) fechas, a.idPro, b.descPro, a.cantidadMov, 
				concat(a.ruc,'-',a.razon) cruc, a.accionMov, a.tipoDoc, a.fec_emi_doc, a.costo
				from cr_inv_movimientos a
					left join cr_inv_productos b on a.idPro = b.idPro
					where a.fechaMov between '$desde' and '$hasta'
					order by a.idMov desc limit 50";
			
			$result = $this->db->query($cSql)->result_array();
			return $result;
		}
	}
}
?>