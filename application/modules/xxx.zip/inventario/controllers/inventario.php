<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//error_reporting(E_ALL & ~E_NOTICE & ~E_PARSE & ~E_WARNING & ~E_ERROR);
//ini_set('display_errors', '1');

class Inventario extends MY_Controller{

    function __construct(){
        parent::__construct();
        $this->load->model('inventario_model');
    }
   
    function index(){
    	// pagina inicial
    	
    	//$this->load->view("inventario/index");
        $this->data['content']         	= "inventario/index";
        $this->_render_page('templates/inv-template', $this->data);
    }

	function agregar(){
		
        if (isset($_POST) && count($_POST) > 0) {
			$rpta = "";
            $hasError = false;
			$data["idAlm"]        = $_POST["idAlm"];
            $data["accionMov"]    = $_POST["accionMov"];
            
            $data["tipodoc"]      = $_POST["tipodoc"];
            $data["idPro"]        = $_POST["idPro"];
            $data["cantidadMov"]  = $_POST["cantidadMov"];
            $data["nroDoc"]       = $_POST["nroDoc"];
            $data["ruc"]          = $_POST["ruc"];
            
            if(strlen($data["accionMov"]) == 0){
                $hasError = true;
                $rpta .= $this->fm->message("Debe ingresar la Accion!,",2);
            }

            if(strlen($data["idPro"]) == 0){
                $hasError = true;
                $rpta .= $this->fm->message("Debe ingresar el Producto!,",2);
            }

            if(strlen($data["cantidadMov"]) == 0 || $data["cantidadMov"]*1 == 0){
                $hasError = true;
                $rpta .= $this->fm->message("Debe ingresar la cantidad!,",2);
            }

            //die("tipodoc:" . $data["tipodoc"]);
            if($data["tipodoc"] == "F" || $data["tipodoc"] == "B"){
                //die("entro aqui");
                if(strlen($_POST["razon"])==0){
                    $hasError = true;
                    $rpta .= $this->fm->message("Debe ingresar la Razon Social!,",2);
                }

                if(strlen($_POST["ruc"])!=11){
                    $hasError = true;
                    $rpta .= $this->fm->message("Debe ingresar RUC correctamente!,",2);
                }

                if(strlen($_POST["nroDoc"])==0){
                    $hasError = true;
                    $rpta .= $this->fm->message("Debe ingresar Nro. documento!,",2);
                }
            }

            $data["razon"]        = $_POST["razon"];
            $data["fec_emi_doc"]  = $_POST["fec_emi_doc"];
            $data["fec_venc_doc"]  = $_POST["fec_venc_doc"];
            $data["motivo"]       = $_POST["motivo"];
            $data["cargo_servicio"] = $_POST["cargo_servicio"];
            $data["costo"]          = $_POST["costo"];
            
            if(strlen($data["costo"]) == 0 || $data["costo"]*1 == 0){
                $hasError = true;
                $rpta .= $this->fm->message("Debe ingresar el costo!,",2);
            }

            if(!$hasError){
                $rpta = $this->inventario_model->grabar($data);
            }
            $ar['error'] = $hasError;
            $ar['message'] = $rpta;
            echo json_encode($ar);
		}else{
			//$this->load->view("inventario/agregar");

	        $this->data['content']         	= "inventario/agregar";
	        $this->_render_page('templates/inv-template', $this->data);

		}
	}

    function entradas(){
        // pagina inicial
        $visualizacion = $_POST["visualizacion"];
        
        //echo $visualizacion;
        if($visualizacion == 1){
            //die("en jaque");
            $this->data['content']          = "inventario/entradas"; 
            $this->_render_page('templates/inv-template', $this->data);
        }else{
            //die("en posicion");
            $this->load->view("inventario/entradas");
        }
    }

    function obtener_ruc(){
        $data['razon'] = $_POST["razon"];
        echo $this->load->view("ruc",$data);
    }

    function rep_entradas(){

        if(isset($_POST["desde"])){
            $data["opcion"] = "1";
            $data["desde"] = $_POST["desde"];
            $data["hasta"] = $_POST["hasta"];

            //die($data["hasta"]);
            $data["titulo"] = "Entradas " . $this->fm->ymd_dmy($data["desde"]) . " hasta " . $this->fm->ymd_dmy($data["hasta"]);
            //$data["titulo"] = "Reporte de Entradas ";
            $data["result"] = $this->inventario_model->reporte($data);

            $this->load->view("reporte1", $data);
        }else{
            
            $data["titulo"] = "Reporte de Entradas ";
            $data['content'] = "rep_entradas";

           $this->_render_page('templates/inv-template', $data);
        }
    }

    function agregar_producto(){
        
        if(isset($_POST["descPro"]) && strlen($_POST["descPro"])>0){
            
            $this->load->model('producto/producto_model');
            echo $this->producto_model->agregar();
        }else{
            $this->data['content']          = "producto/agregar"; // se carga en un view
            $this->_render_page('templates/inv-template', $this->data);
        }
        
    }
}

?>